#include "dos.h"
#include "stdio.h"
#include "stdlib.h"
#include "graphics.h"

FILE *fp_hzk,*fp_asc;
void OutText(int x,int y,unsigned char color,unsigned char *hz);

int main()
{
    int gd=VGA,gm=VGAHI;
    int i = 0;
    int x,y,len,color,y8X8=2,y8X16=16,bottom=447;
    int wl=0,wt=0,wr=1000,wb=1000; 
    unsigned long times=1,time1=0,time2=0;
    unsigned char tmpstr[100],
	*demon0="�����ӡ���Ϊ��ͬ����׳���Լ�",
	*demon1="����������",
	*demon2="�������ƿ������λش�����Ӫ" ,
	*demon3="�˰���������ˣ���ʮ�ҷ�������" ,
	*demon4="ɳ������" , 
	*demon5="����һ��������ʮ����" ;
    if( (fp_hzk=fopen("C:\\TURBOC3\\Hzk16.txt","rb"))==NULL ){ 
        printf("FILE OPEN ERROR\n");
        exit(1);
    }
    if( (fp_asc=fopen("C:\\TURBOC3\\ASC.txt","rb"))==NULL ){
        printf("FILE OPEN ERROR");
        fclose(fp_hzk);
        exit(1);
    }
    gd=DETECT;gm=0;
    initgraph(&gd,&gm,"c:\\TURBOC3\\BGI");
    
    
    setfillstyle(WIDE_DOT_FILL,BLACK);
    bar(0,0,400,800);
    setfillstyle(SOLID_FILL,WHITE);
    bar(wl,wt,wr,wb);
    setviewport(wl,wt,wr,wb,1); 

    for(i=x=y=0;i<=10;i++,y+=16){
       switch (i)
       	{
       	   case 0:	
       	      sprintf(tmpstr,demon0,wl,wt,wr,wb,x,y);
			  OutText(x,y,GREEN,tmpstr);
			  break;
		   case 1:	
		     sprintf(tmpstr,demon1,wl,wt,wr,wb,x,y);
			  OutText(x,y,BLUE,tmpstr);
			  break;		  
		   case 2:	
		     sprintf(tmpstr,demon2,wl,wt,wr,wb,x,y);
			  OutText(x,y,RED,tmpstr);
			  break;
		   case 3:	
		     	sprintf(tmpstr,demon3,wl,wt,wr,wb,x,y);
				OutText(x,y,GREEN,tmpstr);
			  	break;
		   case 4:	
		      sprintf(tmpstr,demon4,wl,wt,wr,wb,x,y);
			  OutText(x,y,BLACK,tmpstr);
			  break;
		   case 5:	
		      sprintf(tmpstr,demon5,wl,wt,wr,wb,x,y);
			  OutText(x,y,RED,tmpstr);
			  break;	
		   default:
		   	  break;
    	 }}
    setviewport(0,0,639,479,1); 
    getch();

    bar(0,463,639,479);
    OutText(0,463,LIGHTGREEN,tmpstr);
    getch();
    fclose(fp_hzk);
    fclose(fp_asc);
    closegraph();
}

void OutText(int x,int y,unsigned char color,unsigned char *hz)
{
    long i;
    char far *ptr;
    int movebit,ybit;
    struct viewporttype v;
    unsigned char by[32],by1,by2,byte1,byte2,tmp,*byptr;
    getviewsettings(&v);
    x+=v.left; y+=v.top; 
    if( x<0 || y<0 || x>=639 || y>=479 || x>=v.right || y>=v.bottom ) return;
    ybit= y+15>=v.bottom?v.bottom-y:16; 
    ybit= ybit<=0?0:ybit;

    outportb(0x3ce,5);   outportb(0x3cf,2);

    outportb(0x3c4,2);   outportb(0x3c5,255);
    outportb(0x3ce,8);
    while(*hz){
        byte1=(unsigned char)*hz;  byte2=(unsigned char)*(hz+1);
        if( (byte1>=0xa1 && byte1<=0xfe)&&(byte2>=0xa1 && byte2<=0xfe) ){ 
            byptr=by;
            if(x+15>v.right) break; 
            i=(byte1-0xa1)*94+byte2-0xa1;
            i<<=5;
            fseek(fp_hzk,i,SEEK_SET);
            fread(by,32,1,fp_hzk); 
            movebit=x%8; 
            for(i=0;i<ybit;i++){
                ptr=MK_FP( 0xA000,(y+i)*80+x/8 );
                by1=*byptr++; by2=*byptr++;
    
                outportb( 0x3cf,by1>>movebit );
                tmp=*ptr;  *ptr++=color; 
              
                outportb( 0x3cf,(by1<<(8-movebit))|(by2>>movebit) );
                tmp=*ptr;  *ptr++=color;
              
                if( movebit!=0 ){
               
                    outportb( 0x3cf,by2<<(8-movebit) );
                    tmp=*ptr;  *ptr=color;
                }
            } 
            x+=16;  hz+=2;
        } 
        else{ 
            if(x+7>v.right) break; 
            fseek(fp_asc,byte1*16,SEEK_SET);
            fread(by,16,1,fp_asc); 
            movebit=x%8; 
            for(i=0;i<ybit;i++){
                ptr=MK_FP( 0xA000,(y+i)*80+x/8 );
                by1=*(by+i);
                outportb( 0x3cf,by1>>movebit );
                tmp=*ptr;  *ptr++=color;
                if( movebit!=0 ){
                    outportb( 0x3cf,by1<<(8-movebit) );
                    tmp=*ptr;  *ptr++=color;
                }
            } 
            x+=8;   hz++;
        } 
    } 
    tmp=tmp;
    outportb(0x3ce,8);   outportb(0x3cf,255);
    outportb(0x3ce,5);   outportb(0x3cf,0);
} 
