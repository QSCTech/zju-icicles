#include "include/graphics.h"
#include "include/extgraph.h"
#include "include/genlib.h"
#include "include/simpio.h"
#include "include/random.h"
#include "include/strlib.h"
#include <conio.h>
#include <stdio.h>
#include <stdlib.h>
#include <stddef.h>
#include <windows.h>
#include <olectl.h>
#include <mmsystem.h>
#include <wingdi.h>
#include <ole2.h>
#include <ocidl.h>
#include <winuser.h>
#include <math.h>//include
#define FONTP 0.02 
#define START 0
int distance = 0;  
int height = 0;
int width = 0;
double x,y;
void PrintText(double x, double y);
void NormalShow(unsigned char * s);
void BlankText(double x, double y);

void Main(){
	InitGraphics();//initialize the graph
	x = GetWindowWidth();
	y = GetWindowHeight();
	unsigned char s[150]="���ٱ��š� ����������� ������������� ����������֣�����������Ʋʡ� �Ǻ��ϵĽ��� ��Ϧ���е����  ������־Ħ�٢�ڢ�"; 

	while(s[distance] != '\0')
	{	
		if(s[distance] == ' ')
		{
			width = 0;
			height ++;
			distance++;
		}
		else
		{ 
			NormalShow(s);
			distance = distance + 2;
			width = width+2;
			if(START + 8*2*FONTP+0.32*width >= x)
			{
				height++;
                width = 0;
			} 
		}	
	}
	
}

void NormalShow(unsigned char * s)
{
	int w,q,ofs;
	FILE *fp;
	unsigned char u[32];

	q = s[distance] - 0xA1;
	w = s[distance+1] - 0xA1;
	ofs = q*94 + w + 256;
	if((fp = fopen("mhzk16c.�ֿ�","rb")) == NULL)
	{
		MovePen(5,5);
		DrawTextString("File Open Error\n");
		exit(0);
	}
	fseek(fp,ofs*32L,SEEK_SET);
	fread(u, 1, 32, fp);
	int i,j,m;
	for(j=0;j<16;j++)
	{
		m=0x80;
		for(i=0;i<8;i++){
			if(u[j*2] & m)
				PrintText(START + i*2*FONTP+0.32*width,6.75 - j*FONTP*2-0.7*height); 
			else			 
				BlankText(START + i*2*FONTP+0.32*width,6.75 - j*FONTP*2-0.7*height);
			m >>= 1 ;
		}
		m = 0x80;
		for(i=0;i<8;i++)
		{
			if(u[j*2+1] & m)
				PrintText(START+8*FONTP*2 + i*FONTP*2 +0.32*width,6.75 - j*FONTP*2-0.7*height);
			else
				BlankText(START+8*FONTP*2 + i*FONTP*2 +0.32*width,6.75 - j*FONTP*2-0.7*height);
			m >>= 1;			
		}
	}
}//Chinese number Output
/*void NormalShow(unsigned char * s)
{
	char  * txt;
	txt = MK_FP(0xB800,0);
	txt[600] = 'a';
	txt[160*10+80] = 'A';
	txt[160*10+81] = '0x4A';
	
}*///English Number Output 
void PrintText(double x, double y)
{
	MovePen(x,y);
	SetPenColor("black");
	DrawArc(FONTP,0,360);
}
void BlankText(double x, double y)
{
	MovePen(x,y);
	SetPenColor("white");
	DrawArc(FONTP,0,360);
}

