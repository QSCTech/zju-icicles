#include "include/graphics.h"
#include "include/extgraph.h"
#include "include/genlib.h"
#include "include/simpio.h"
#include "include/random.h"
#include "include/strlib.h"
#include <conio.h>
#include <stdio.h>
#include <stdlib.h>
#include <stddef.h>
#include <windows.h>
#include <olectl.h>
#include <mmsystem.h>
#include <wingdi.h>
#include <ole2.h>
#include <ocidl.h>
#include <winuser.h>
#include <math.h>//include
void BlankText(double x, double y);
void NormalShow(unsigned char * s);
void PrintText(double x, double y,int i,int j);
void Main(){
	InitGraphics();//initialize the graph
	unsigned char s[10] = "��";
	NormalShow(s);
}

void NormalShow(unsigned char * s)
{
	int w,q,ofs;
	FILE *fp;
	unsigned char u[32];
	q = s[0] - 0xA1;
	w = s[1] - 0xA1;
	ofs = q*94 + w + 256;
	if((fp = fopen("mhzk16c.�ֿ�","rb")) == NULL)
	{
		MovePen(5,5);
		DrawTextString("File Open Error\n");
		exit(0);
	}
	fseek(fp,ofs*32L,SEEK_SET);
	fread(u, 1, 32, fp);
	int i,j,m;
	for(j=0;j<16;j++)
	{
		m=0x80;
		for(i=0;i<8;i++){
			if(u[j*2] & m)
				PrintText(5 + i*0.25,4 - j*0.25,i,j);
			else			 
				BlankText(5 + i*0.25,4 - j*0.25);
			m >>= 1 ;
		}
		m = 0x80;
		for(i=0;i<8;i++)
		{
			if(u[j*2+1] & m)
				PrintText(7 + i*0.25,4 - j*0.25,i,j);
			else
				BlankText(7 + i*0.25,4 - j*0.25);
			m >>= 1;			
		}
	}
}
void PrintText(double x, double y,int i,int j)
{
	MovePen(x,y);
	switch (i*j%4){
		case 0:
			SetPenColor("green");
			break;
		case 1:
			SetPenColor("yellow");
			break;
		case 2:
			SetPenColor("blue");
			break;
		case 3:
			SetPenColor("red");
			break;
	}
	DrawTextString("*");
}
void BlankText(double x, double y)
{
	MovePen(x,y);
	SetPenColor("white");
	DrawTextString("*");
}
