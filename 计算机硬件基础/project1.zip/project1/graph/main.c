#include "include/graphics.h"
#include "include/extgraph.h"
#include "include/genlib.h"
#include "include/simpio.h"
#include "include/random.h"
#include "include/strlib.h"
#include <conio.h>
#include <stdio.h>
#include <stdlib.h>
#include <stddef.h>
#include <windows.h>
#include <olectl.h>
#include <mmsystem.h>
#include <wingdi.h>
#include <ole2.h>
#include <ocidl.h>
#include <winuser.h>
#include <math.h>//include
void KeyboardEventProcess(int key,int event);//react to keyboard
 
void initail(void);
void WindowGraph(void);
void Drawsin(void);
void Drawx(void);
void Drawln(void);
void Draw2x(void);
void dynamicsin(void);
double flag = 0;
#define pai 3.14159264357
void Main(){
	InitGraphics();//initialize the graph
	WindowGraph(); 
	initail();
	registerKeyboardEvent(KeyboardEventProcess);//register the KeyboardEvent
	int i;
}
void WindowGraph(void)
{
	SetPenColor("white");
	int i;
	MovePen(0,0);
	for(i=0;i<1000;i++)
		{
			DrawLine(20,0);
			DrawLine(0,0.01);
			DrawLine(-20,0);
			DrawLine(0,0.01);
		}
	SetPenColor("black");
}
void initail(void)//draw the x and y
{
	MovePen(5,3.5);
	DrawTextString("O");
	MovePen(0,3.5); 
	DrawLine(15,0);
	MovePen(5,0);
	DrawLine(0,15); 
}//initial the graph
void KeyboardEventProcess(int key,int event)
{
		switch(event)
		{
			case KEY_DOWN://to switch the graph printed
				switch(key){
					case VK_UP:
						WindowGraph();
						initail();
						Drawsin();
						break;
					case VK_DOWN:
						WindowGraph();
						initail();
						Drawx();
						break;
					case VK_LEFT:
						WindowGraph();
						initail();
						Drawln();
						break;
					case VK_RIGHT:
						WindowGraph();
						initail();
						Draw2x();
						break;
					case VK_F1:
						flag = flag + 10;
						WindowGraph();
						initail();
						dynamicsin();
						break;
					case VK_F2:
						flag = flag - 20;
						WindowGraph();
						initail();
						dynamicsin();
						break;
				}
		}
}
void Drawsin(void)
{
	int i;
	SetPenColor("blue");
	for(i=-4000;i<4000;i++)
	{ 
		MovePen(5+i*0.01,3.5+sin(i*0.01));
		DrawTextString("*");
	}
	SetPenColor("black");
}
void Drawx(void)
{
	int i;
	for(i=-4000;i<4000;i++)
	{
		MovePen(5+i*0.01,3.5+i*0.01);
		DrawTextString("*");
	}
}
void Drawln(void)
{
	int i;
	for(i=-8000;i<8000;i++)
	{
		MovePen(5+i*0.005,3.5+exp(i*0.005));
		DrawTextString("*");
	}
}
void Draw2x(void)
{
	int i;
	for(i=-4000;i<4000;i++)
	{
		MovePen(5+i*0.01,3.5+pow(2,i*0.01));
		DrawTextString("*");
	}
}
void dynamicsin(void)
{
	int i;
	for(i=-4000;i<4000;i++)
	{
		MovePen(5+i*0.01,3.5+sin(i*0.01+flag/360*pai));
		DrawTextString("*");
	}
} 

