#include<stdio.h>
#include<math.h>
#include<stdlib.h>
#include<windows.h>

#define PI 3.1415926

int main() 
{
	double y;int x,m;
	int loop;
	for(loop=0;loop<=1000;loop++){
		if(loop%2==0){
  			  for(y=1;y>=0;y=y-0.1){
  	   		   		m=asin(y)*10;
   	  		   		for(x = 1;x < m;x++) printf(" ");printf("*");
  	  		   		for(;x < (PI*10-m);x++) printf(" ");printf("*\n");
 	 		  }  
  	  		  for(;y>=-1;y=y-0.1){
  	      			m=asin(y)*10;
  	      			for(x=1;x<PI*10-m;x++) printf(" ");printf("*");
 	  			    for(;x<PI*20+m;x++) printf(" ");printf("*\n");
 	  		  }
 	  	}    
		Sleep(300);
		system("cls");	
	}
}
