//: C03:FunctionCallCast.cpp
// From Thinking in C++, 2nd Edition
// Available at http://www.BruceEckel.com
// (c) Bruce Eckel 2000
// Copyright notice in Copyright.txt
int main() {
  float a = float(200);
  // This is equivalent to:
  float b = (float)200;
} ///:~
