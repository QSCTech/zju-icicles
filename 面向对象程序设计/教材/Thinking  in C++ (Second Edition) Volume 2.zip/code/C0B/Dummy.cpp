//: C0B:Dummy.cpp
// From "Thinking in C++, 2nd Edition, Volume 2"
// by Bruce Eckel & Chuck Allison, (c) 2001 MindView, Inc.
// Available at www.BruceEckel.com.
// To give the makefile at least one target 
// for this directory
int main() {} ///:~
