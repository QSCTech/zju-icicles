package com.example;

public class incBookStockRequest {
    public int bookId;
    public int deltaStock;
}
