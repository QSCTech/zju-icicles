package com.library.restservice;

public record Greeting(long id, String content) { }
