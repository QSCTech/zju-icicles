


// export default {
//     dev: {
//       '/': {
//         target: 'localhost:8080',
//         changeOrigin: true,
//         pathRewrite: { '^/': '' },
//         secure: false,
//       },
//     },
// } as IConfig;