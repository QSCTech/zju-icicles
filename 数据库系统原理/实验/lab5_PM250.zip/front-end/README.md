# README


## Description

**图书管理系统**

## Usage

```bash
# 安装依赖
npm install

# 启动服务
npm start
```

