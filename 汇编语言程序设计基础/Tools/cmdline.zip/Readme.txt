This archive contains all files necessary to compile the Command line plugin
for OllyDbg using Borland C++ Builder 5.0. This plugin requires at least
OllyDbg 1.07b. Command line plugin is a freeware, feel free to modify the
code according to your needs. I would be glad if you send me your modifications
so that I will be able to include them into the next release.

Files:

cmdexec.c   - command processing
cmdline.bpr - BCB5 project file
cmdline.cpp - main file required by BCB5
cmdline.dll - plugin
command.c   - plugin window and interface to OllyDbg
license.txt - legal stuff
ollydbg.lib - import library for OllyDbg 1.07b
plugin.h    - plugin API header file
readme.txt  - this file
