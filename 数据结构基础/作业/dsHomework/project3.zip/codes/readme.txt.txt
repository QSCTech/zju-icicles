open the   by clion , compile it by  c++11 or higher version.
you can open the test by visual studio code, and test the input and the output.